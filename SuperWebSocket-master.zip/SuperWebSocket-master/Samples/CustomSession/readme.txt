﻿How to use this CustomSession project?

1. Copy this project's output to working directory of SuperWebSocket's running container,
SuperWebSocketService, SuperWebSocketWeb or your own container.

2. Update the configuration file in running container according the file SuperWebSocket.Service.exe.config in current project.