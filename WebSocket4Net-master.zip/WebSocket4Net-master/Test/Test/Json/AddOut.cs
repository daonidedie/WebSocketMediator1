﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WebSocket4Net.Test.Json
{
    public class AddOut
    {
        public int Result { get; set; }
    }
}
