﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WebSocket4Net.Test.Json
{
    public class AddIn
    {
        public int A { get; set; }
        public int B { get; set; }
    }

}
