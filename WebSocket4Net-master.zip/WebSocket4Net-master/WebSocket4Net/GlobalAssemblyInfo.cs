﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Diagnostics.CodeAnalysis;

[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("WebSocket4Net")]
[assembly: AssemblyProduct("WebSocket4Net")]
[assembly: AssemblyCopyright("Copyright © www.supersocket.net 2018")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion("0.15.2.11")]
[assembly: AssemblyFileVersion("0.15.2.11")]
