﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("WebSocket4Net for .NET 3.5")]
[assembly: AssemblyDescription("WebSocket4Net for .NET 3.5")]
[assembly: ComVisible(false)]
[assembly: Guid("5A615DD9-4254-4AC0-937B-843AF9419965")]