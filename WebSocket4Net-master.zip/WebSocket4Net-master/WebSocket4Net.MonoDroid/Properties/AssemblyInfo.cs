﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("WebSocket4Net for Mono for Android")]
[assembly: AssemblyDescription("WebSocket4Net for Mono for Android")]
[assembly: ComVisible(false)]
[assembly: Guid("8767F242-8DD1-4BF0-8A10-D10FF0492983")]