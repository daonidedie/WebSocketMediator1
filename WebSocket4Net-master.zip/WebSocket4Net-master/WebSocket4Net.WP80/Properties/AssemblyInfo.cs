﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("WebSocket4Net for WindowsPhone 8.0")]
[assembly: AssemblyDescription("WebSocket4Net for WindowsPhone 8.0")]
[assembly: ComVisible(false)]
[assembly: Guid("F94AB72D-B6F8-4FAE-A2AD-1260ADA1302F")]