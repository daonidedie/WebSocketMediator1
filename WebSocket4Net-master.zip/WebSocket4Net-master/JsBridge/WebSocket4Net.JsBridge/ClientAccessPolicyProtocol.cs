﻿using System;
using System.Net;
using System.Windows.Browser;
using System.ComponentModel;

namespace WebSocket4Net.JsBridge
{
    class ClientAccessPolicyProtocol
    {
        internal const int Http = 0;
        internal const int Tcp = 1;
    }
}
