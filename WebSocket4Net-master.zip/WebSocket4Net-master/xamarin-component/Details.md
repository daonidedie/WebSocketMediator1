# WebSocket4Net details

a .NET websocket client implementation.

It originated from SuperWebSocket WebSocket Client. For better developing of the websocket client, it was separated from SuperWebSocket and was renamed to WebSocket4Net.

WebSocket4Net provides websocket client implementation for many different kinds of runtime:

- .Net 2.0
- .Net 3.5
- .Net 4.0
- .Net 4.5
- Mono
- Silverlight 4/5
- WindowsPhone
- Xamarin.Android
- Xamarin.iOS