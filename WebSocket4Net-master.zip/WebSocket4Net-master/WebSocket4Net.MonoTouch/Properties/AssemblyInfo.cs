﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("WebSocket4Net for MonoTouch")]
[assembly: AssemblyDescription("WebSocket4Net for MonoTouch")]
[assembly: ComVisible(false)]
[assembly: Guid("b59453fe-1b25-463d-a7dd-10f1cf5dbe06")]